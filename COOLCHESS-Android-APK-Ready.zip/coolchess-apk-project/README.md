# COOLCHESS Android APK project

This project wraps the supplied COOLCHESS `index.html` in an Android app using Capacitor. GitHub Actions builds a debug APK and publishes it as an artifact.

## Build the APK from a phone using GitHub

1. Create or open your GitHub repository.
2. Upload the **contents** of this folder to the repository root. The root should contain `package.json`, `capacitor.config.json`, `www/`, and `.github/` (do not upload this whole folder as a nested folder).
3. Commit the files to the default branch.
4. Open the repository's **Actions** tab.
5. Choose **Build COOLCHESS APK** and tap **Run workflow**.
6. Open the completed run. Under **Artifacts**, download `COOLCHESS-APK`.
7. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
8. Install the APK on your Android phone. If Android asks, allow installation from that file manager/browser.

If the workflow fails, open the failed run and inspect the first red step; the error log is needed to diagnose it. A successful build cannot be guaranteed until it has run in your repository.

## Important feature note

This packages the exact supplied web app. Packaging alone does not add online multiplayer, a hosted backend, or the Stockfish chess engine if those are not already implemented in the supplied HTML. This workflow produces a debug APK, not a Play Store release-signed APK.
